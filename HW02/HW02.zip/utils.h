#pragma once

void util_print_int_array(int* array, int array_count);